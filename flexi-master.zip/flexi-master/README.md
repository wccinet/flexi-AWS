# flexi-MTV

Google Cloud Shell platform for CMS updates to WatchItNowOrLater.com.

[![Open in Cloud Shell](http://gstatic.com/cloudssh/images/open-btn.svg)](https://console.cloud.google.com/cloudshell/open?git_repo=https%3A%2F%2Fgithub.com%2Fflexi-unwrtn%2Fflexi&page=shell)
